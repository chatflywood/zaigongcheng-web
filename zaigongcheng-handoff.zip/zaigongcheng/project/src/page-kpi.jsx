// page-kpi.jsx — 关键指标 (real data)

function PageKPI() {
  const { kpi, managers, budgetTotals, projectsByBalance, warningSummary } = window.DATA;

  const spendBudgetPct = budgetTotals.budget > 0 ? (budgetTotals.annual_spend / budgetTotals.budget) * 100 : 0;
  const occupiedPct    = budgetTotals.budget > 0 ? (budgetTotals.occupied / budgetTotals.budget) * 100 : 0;
  const warnTotal = warningSummary.reduce((s,w)=>s+w.count, 0);

  const cards = [
    {
      label: '资本性支出年度进度',
      value: kpi.progressPct, target: 100, unit: '%',
      sub: `${kpi.spendYTD.toFixed(1)} / ${kpi.yearTarget} 万`,
      delta: `缺口 ${kpi.deficit.toFixed(1)} 万`, deltaDir: 'up',
      narrative: `已完成年度目标的 ${kpi.progressPct}%，距离全年 ${kpi.yearTarget} 万元目标还差 ${kpi.deficit.toFixed(1)} 万。`,
    },
    {
      label: '转固率',
      value: kpi.transferRate, target: 80, unit: '%',
      sub: '期末余额 vs 年初数',
      delta: kpi.transferRate < 10 ? '低位' : '—', deltaDir: kpi.transferRate < 10 ? 'down' : 'flat',
      narrative: `整体转固率 ${kpi.transferRate.toFixed(2)}%，明显低于 80% 期望值。期末余额仍有较大规模尚未转为固定资产。`,
    },
    {
      label: '预算执行率',
      value: spendBudgetPct, target: 100, unit: '%',
      sub: `${budgetTotals.annual_spend.toFixed(1)} / ${budgetTotals.budget.toFixed(1)} 万`,
      delta: spendBudgetPct > 100 ? '超支' : `${(100-spendBudgetPct).toFixed(1)}pp 待执行`,
      deltaDir: spendBudgetPct > 100 ? 'down' : 'up',
      narrative: `全年支出占预算 ${spendBudgetPct.toFixed(1)}%。其中"其他"、"局房及基础设施"、"有线接入网" 三项已超预算，需关注。`,
    },
    {
      label: '预算占用率',
      value: occupiedPct, target: 90, unit: '%',
      sub: `${budgetTotals.occupied.toFixed(1)} / ${budgetTotals.budget.toFixed(1)} 万`,
      delta: `${(90-occupiedPct).toFixed(1)}pp 未绑定`, deltaDir: occupiedPct < 90 ? 'up' : 'flat',
      narrative: `预算占用率 ${occupiedPct.toFixed(1)}%，无线网占用 97%、有线接入网 118% 已超配。`,
    },
  ];

  // Manager contribution to 本年累计 支出
  const totalSpend = managers.reduce((s,m)=>s+Math.max(m.spendYTD,0), 0) || 1;
  const mgrShares = managers.map(m => ({
    ...m, share: (Math.max(m.spendYTD, 0) / totalSpend) * 100,
  })).sort((a,b)=>b.share - a.share);

  return (
    <div className="page">
      <PageHead
        eyebrow="关键指标 / Quarterly Briefing"
        title="关键指标摘要"
        sub="代替原「大屏」页面。每个指标自带叙事，可截图直接用作周/月度汇报。"
        meta={[`数据截止 · 当前周期`, `年度目标 ${kpi.yearTarget} 万`, `${warnTotal} 条预警`]}
        actions={<>
          <button className="btn ghost"><Icn d={I.print}/> 打印 A4</button>
          <button className="btn"><Icn d={I.share}/> 投屏</button>
          <button className="btn primary"><Icn d={I.download}/> 导出 PNG</button>
        </>}
      />

      {/* — KPI gauges — */}
      <div className="section">
        <SectionHead title="四个核心指标" sub="对比目标 · 含叙事说明"/>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1, background: 'var(--line)', border: '1px solid var(--line)', borderRadius: 'var(--r-lg)', overflow: 'hidden' }}>
          {cards.map((k,i) => {
            const accent = k.value >= k.target * 0.95 ? 'var(--ok)' : k.value >= k.target * 0.80 ? 'var(--accent)' : k.value >= k.target * 0.5 ? 'var(--warn)' : 'var(--bad)';
            return (
              <div key={i} style={{ background: 'var(--surface)', padding: '28px 30px', display: 'grid', gridTemplateColumns: '120px 1fr', gap: 24, alignItems: 'center' }}>
                <div style={{ position: 'relative', display: 'grid', placeItems: 'center' }}>
                  <Donut value={Math.min(k.value, 100)} size={120} stroke={10} accent={accent}/>
                  <div style={{ position: 'absolute', textAlign: 'center' }}>
                    <div className="mono" style={{ fontSize: 24, fontWeight: 500, color: 'var(--ink)', letterSpacing: '-0.02em', lineHeight: 1 }}>
                      {k.value.toFixed(1)}
                    </div>
                    <div style={{ fontSize: 10, color: 'var(--ink-3)', marginTop: 2 }}>目标 {k.target}{k.unit}</div>
                  </div>
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 13, color: 'var(--ink-2)', fontWeight: 500, marginBottom: 4 }}>{k.label}</div>
                  <div style={{ fontSize: 11.5, color: 'var(--ink-3)', marginBottom: 10, fontFamily: 'var(--font-mono)' }}>{k.sub}</div>
                  <div style={{ marginBottom: 10 }}>
                    <span className={`delta ${k.deltaDir}`} style={{ fontFamily: 'var(--font-mono)', fontSize: 11.5 }}>
                      {k.deltaDir === 'up' && <span className="tri-up"/>}
                      {k.deltaDir === 'down' && <span className="tri-dn"/>}
                      {k.deltaDir === 'flat' && <span className="tri-eq"/>}
                      {k.delta}
                    </span>
                  </div>
                  <div style={{ fontSize: 12.5, color: 'var(--ink-2)', lineHeight: 1.55, paddingTop: 12, borderTop: '1px dashed var(--line)' }}>
                    {k.narrative}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* — Manager contribution + Top balances — */}
      <div className="section">
        <SectionHead title="责任分布 & 最大在建" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 24 }}>
          <div className="card">
            <CardHead title="本年支出 · 管理员贡献" sub="占总支出比重"/>
            <div className="card-body" style={{ padding: '16px 20px' }}>
              {mgrShares.map((m,i) => (
                <div key={m.name} style={{
                  display: 'grid', gridTemplateColumns: '80px 1fr 70px 50px',
                  alignItems: 'center', gap: 12, padding: '10px 0',
                  borderBottom: i < mgrShares.length -1 ? '1px dashed var(--line)' : 'none',
                }}>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{m.name}</div>
                  <div style={{ height: 6, background: 'var(--paper-2)', borderRadius: 3, overflow: 'hidden' }}>
                    <div style={{ height: '100%', width: `${m.share}%`, background: m.spendYTD < 0 ? 'var(--bad)' : 'var(--accent)' }}/>
                  </div>
                  <div className="num mono" style={{ fontSize: 12, color: m.spendYTD < 0 ? 'var(--bad)' : 'var(--ink)' }}>
                    {m.spendYTD.toFixed(1)}万
                  </div>
                  <div className="num mono muted" style={{ fontSize: 11 }}>{m.share.toFixed(1)}%</div>
                </div>
              ))}
            </div>
          </div>

          <div className="card">
            <CardHead title="期末余额 · Top 6" sub="规模最大的在建工程"/>
            <div className="card-body" style={{ padding: 0 }}>
              {projectsByBalance.slice(0,6).map((p,i) => (
                <div key={p.name} style={{
                  padding: '14px 20px',
                  borderBottom: i < 5 ? '1px solid var(--line)' : 'none',
                  display: 'grid', gridTemplateColumns: '24px 1fr 80px', alignItems: 'center', gap: 12,
                }}>
                  <span className="mono" style={{ fontSize: 11, color: 'var(--ink-3)' }}>{i+1}</span>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, color: 'var(--ink)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={p.name}>{p.name}</div>
                    <div style={{ fontSize: 11, color: 'var(--ink-3)', marginTop: 2 }}>{p.manager}</div>
                  </div>
                  <div className="num mono" style={{ fontSize: 14, fontWeight: 500 }}>{p.balance.toFixed(1)}<span style={{ fontSize: 10, color: 'var(--ink-3)', marginLeft: 2, fontFamily: 'var(--font-sans)', fontWeight: 400 }}>万</span></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* — Narrative summary — */}
      <div className="section">
        <SectionHead title="一段话摘要 · 可粘贴" sub="为周报起草"/>
        <div className="card" style={{ padding: '28px 32px', background: 'var(--surface-2)', borderStyle: 'dashed' }}>
          <div style={{ fontSize: 14.5, lineHeight: 1.85, color: 'var(--ink-2)', maxWidth: 880, fontFamily: 'var(--font-serif)' }}>
            本年累计资本性支出 <strong className="mono" style={{color:'var(--ink)'}}>{kpi.spendYTD.toFixed(2)} 万元</strong>（年度目标 {kpi.yearTarget} 万，进度 <strong style={{color:'var(--accent)'}}>{kpi.progressPct}%</strong>），年度缺口 <strong className="mono" style={{color:'var(--warn)'}}>{kpi.deficit.toFixed(2)} 万</strong>。全年预算执行率 <strong style={{color: spendBudgetPct > 100 ? 'var(--bad)' : 'var(--accent)'}}>{spendBudgetPct.toFixed(1)}%</strong>，其中{budgetTotals.annual_spend > budgetTotals.budget ? '局房及基础设施、其他、有线接入网三项存在超支情况' : '分布基本均衡'}。在建工程期末余额规模较大，整体转固率仅 <strong className="mono" style={{color:'var(--bad)'}}>{kpi.transferRate.toFixed(2)}%</strong>，需在下一周期集中推进转固。已下单待收货 <strong className="mono" style={{color:'var(--ink)'}}>{kpi.pending.toFixed(2)} 万</strong>，对应 {window.DATA.activeProjects} 个在建项目。
          </div>
          <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--line)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>
            <span>AUTO-DRAFTED · 基于上传数据</span>
            <button className="btn ghost"><Icn d={I.download} size={12}/> 复制纯文本</button>
          </div>
        </div>
      </div>
    </div>
  );
}

window.PageKPI = PageKPI;
