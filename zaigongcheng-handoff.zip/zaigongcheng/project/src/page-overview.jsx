// page-overview.jsx — design intent page

function PageOverview({ goto }) {
  const principles = [
    { n: '01', t: '克制压倒装饰', d: '原平台以 dark-glass 大屏 + 高饱和图表为核心，本设计反其道：纸感背景、单一强调色、高对比层级。装饰只在必要处出现。' },
    { n: '02', t: '空间是数据的呼吸', d: '所有 KPI 之间留 1px 分隔线即可；section 之间用 56px 垂直距离；卡片之间用 24px。空白本身就是分组。' },
    { n: '03', t: '数字优先于图表', d: '数字是这个产品的主角。所有数字 tabular-nums，右对齐，使用同一套等宽字。图表只在能解释时间趋势或分布时出现，不做"装饰图"。' },
    { n: '04', t: '可截图汇报', d: '每个区块独立成稿，配色和留白考虑了被截图后贴入周报 PPT 的场景。无 deep-dark 玻璃面板。' },
  ];

  const screens = [
    { id: 'dashboard', t: '在建工程', d: '资本性支出进度、管理员排名、四类工程预警、转固推进', count: '2026.03 数据' },
    { id: 'budget',    t: '预算立项', d: '总预算 vs 已占用/预占用，按专业拆分，新建项目流水', count: '7 个专业' },
    { id: 'kpi',       t: '关键指标', d: '4 个核心 KPI 仪表盘 + 重点工作清单（替代旧大屏）', count: '可投屏' },
  ];

  return (
    <div className="page">
      <PageHead
        eyebrow="重设计提案 · v0.4"
        title={`给「工程数据分析」一次安静的呼吸`}
        sub="原平台信息密度高、风格混搭（dark 大屏 + light 表格）。这版重新设定了视觉系统：纸感、克制、可截图。三个核心页面都保留原始数据流（上传 .xlsx → 自动渲染），只重做了呈现层。"
        meta={['提案人 · Claude', '基于 dashboard.html / budget.html / key-indicators.html', '右下角 Tweaks 可切换 3 个视觉方向']}
      />

      {/* — Visual system at-a-glance — */}
      <div className="section">
        <SectionHead title="视觉系统" sub={<span>切换右下角 <strong>Variant</strong> 查看 3 个方向</span>} />
        <div style={{
          display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', gap: 16,
        }}>
          {/* Type sample */}
          <div className="card">
            <div className="card-head"><h3>字号 & 韵律</h3><span className="sub">size scale</span></div>
            <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div>
                <div style={{ fontSize: 30, lineHeight: 1.1, fontWeight: 500, letterSpacing: '-0.02em', color: 'var(--ink)' }}>页面标题 30 / -2%</div>
              </div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--ink)' }}>卡片标题 14 / 500</div>
                <div style={{ fontSize: 13, color: 'var(--ink-2)', marginTop: 2 }}>正文 13 — 表格内行</div>
              </div>
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.06em',
                color: 'var(--ink-3)', textTransform: 'uppercase',
              }}>SECTION 11 / MONO / UPPERCASE</div>
              <div style={{
                fontVariantNumeric: 'tabular-nums',
                fontFamily: 'var(--font-mono)',
                fontSize: 28,
                fontWeight: 500,
                color: 'var(--ink)',
                letterSpacing: '-0.02em',
              }}>
                ¥ 12,408.50<span style={{ fontSize: 13, color: 'var(--ink-3)', marginLeft: 6, fontFamily: 'var(--font-sans)', fontWeight: 400 }}>万</span>
              </div>
            </div>
          </div>

          {/* Palette */}
          <div className="card">
            <div className="card-head"><h3>色板</h3><span className="sub">9 + 3</span></div>
            <div className="card-body" style={{ padding: 0 }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 1, background: 'var(--line)' }}>
                {[
                  ['Paper',   'var(--paper)'],
                  ['Surface', 'var(--surface)'],
                  ['Line',    'var(--line)'],
                  ['Ink-3',   'var(--ink-3)'],
                  ['Ink',     'var(--ink)'],
                ].map(([n, c]) => (
                  <div key={n} style={{ background: 'var(--surface)', padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <div style={{ height: 28, background: c, borderRadius: 4, border: '1px solid var(--line)' }} />
                    <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>{n}</div>
                  </div>
                ))}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 1, background: 'var(--line)' }}>
                {[
                  ['Accent', 'var(--accent)'],
                  ['OK',     'var(--ok)'],
                  ['Warn',   'var(--warn)'],
                  ['Bad',    'var(--bad)'],
                ].map(([n, c]) => (
                  <div key={n} style={{ background: 'var(--surface)', padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <div style={{ height: 28, background: c, borderRadius: 4 }} />
                    <div style={{ fontSize: 10, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>{n}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Components mini */}
          <div className="card">
            <div className="card-head"><h3>组件细胞</h3><span className="sub">density · loose</span></div>
            <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                <span className="pill ok"><span className="dot" />已完成</span>
                <span className="pill warn"><span className="dot" />待审核</span>
                <span className="pill bad"><span className="dot" />超期</span>
                <span className="pill accent">新建</span>
              </div>
              <div>
                <CellBar pct={87.4} />
              </div>
              <div>
                <CellBar pct={43.2} />
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="btn">次要</button>
                <button className="btn primary">主要</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* — Principles — */}
      <div className="section">
        <SectionHead title="四个原则" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 1, background: 'var(--line)', border: '1px solid var(--line)', borderRadius: 'var(--r-lg)' }}>
          {principles.map(p => (
            <div key={p.n} style={{ background: 'var(--surface)', padding: '24px 26px' }}>
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--accent)',
                letterSpacing: '0.08em', marginBottom: 10,
              }}>P · {p.n}</div>
              <div style={{ fontSize: 16, fontWeight: 500, color: 'var(--ink)', letterSpacing: '-0.005em', marginBottom: 6 }}>{p.t}</div>
              <div style={{ fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.6 }}>{p.d}</div>
            </div>
          ))}
        </div>
      </div>

      {/* — Page index — */}
      <div className="section">
        <SectionHead title="三个页面" sub="点击进入查看完整重设计" />
        <div style={{ display: 'flex', flexDirection: 'column', border: '1px solid var(--line)', borderRadius: 'var(--r-lg)', overflow: 'hidden', background: 'var(--surface)' }}>
          {screens.map((s, i) => (
            <div
              key={s.id}
              onClick={() => goto(s.id)}
              style={{
                padding: '20px 24px',
                display: 'flex', alignItems: 'center', gap: 24,
                borderBottom: i < screens.length - 1 ? '1px solid var(--line)' : 'none',
                cursor: 'pointer',
                transition: 'background 120ms',
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--surface-2)'}
              onMouseLeave={e => e.currentTarget.style.background = 'var(--surface)'}
            >
              <div style={{
                fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--ink-3)',
                width: 24,
              }}>0{i+1}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--ink)' }}>{s.t}</div>
                <div style={{ fontSize: 12.5, color: 'var(--ink-3)', marginTop: 3 }}>{s.d}</div>
              </div>
              <div style={{ fontSize: 11, color: 'var(--ink-3)', fontFamily: 'var(--font-mono)' }}>{s.count}</div>
              <Icn d={I.arrow} size={14} />
            </div>
          ))}
        </div>
      </div>

      {/* — What was preserved — */}
      <div className="section">
        <SectionHead title="保留的部分" />
        <div style={{
          background: 'var(--surface)', border: '1px solid var(--line)',
          borderRadius: 'var(--r-lg)', padding: '24px 28px',
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32,
        }}>
          <div>
            <div style={{ fontSize: 12, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>数据流</div>
            <ul style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 13, color: 'var(--ink-2)' }}>
              <li>• 上传 .xlsx → 前端解析 → 即时渲染</li>
              <li>• 不依赖后端，每次会话独立</li>
              <li>• 数据字段、报表口径、预警逻辑均来自原 PRD</li>
            </ul>
          </div>
          <div>
            <div style={{ fontSize: 12, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 10 }}>新增的部分</div>
            <ul style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 13, color: 'var(--ink-2)' }}>
              <li>• 三个视觉变体（Editorial / Software / Print）切换</li>
              <li>• 三档密度（紧凑 / 舒适 / 宽松）</li>
              <li>• 截图友好的"汇报模式"区块布局</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

window.PageOverview = PageOverview;
