// shared.jsx — small primitives used across pages

const Icn = ({ d, size = 14, stroke = 1.5 }) => (
  <svg className="icn" width={size} height={size} viewBox="0 0 16 16" fill="none">
    <path d={d} stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// Icon library — minimal stroke set
const I = {
  upload:    "M8 11V3M8 3l-3 3M8 3l3 3M3 12v1.5h10V12",
  table:     "M2 4h12M2 8h12M2 12h12M5 4v8M11 4v8",
  chart:     "M2 13h12M4 10v3M7 6v7M10 8v5M13 4v9",
  layers:    "M8 2l6 3-6 3-6-3 6-3zM2 8l6 3 6-3M2 11l6 3 6-3",
  gauge:     "M3 11a5 5 0 0110 0M8 11l3-3",
  doc:       "M4 2h6l2 2v10H4V2zM10 2v2h2",
  search:    "M7 12a5 5 0 100-10 5 5 0 000 10zM11 11l3 3",
  download:  "M8 3v8M5 8l3 3 3-3M3 13h10",
  ext:       "M6 3H3v10h10v-3M9 3h4v4M13 3l-6 6",
  filter:    "M2 4h12M4 8h8M6 12h4",
  more:      "M8 4v.01M8 8v.01M8 12v.01",
  warn:      "M8 2l6 11H2L8 2zM8 6v4M8 12v.01",
  check:     "M3 8l3 3 7-7",
  arrow:     "M3 8h10M9 4l4 4-4 4",
  refresh:   "M2 4l1 3 3-1M14 12l-1-3-3 1M3 7a5 5 0 019-1M13 9a5 5 0 01-9 1",
  calendar:  "M2 5h12v9H2V5zM2 5V3h12v2M5 2v3M11 2v3",
  user:      "M8 8a3 3 0 100-6 3 3 0 000 6zM2 14c0-3 3-5 6-5s6 2 6 5",
  command:   "M5 5h6v6H5zM5 5V3a2 2 0 00-2 2h2zM11 5V3a2 2 0 012 2h-2zM5 11v2a2 2 0 01-2-2h2zM11 11v2a2 2 0 002-2h-2z",
  sparkle:   "M8 2l1.5 4.5L14 8l-4.5 1.5L8 14l-1.5-4.5L2 8l4.5-1.5L8 2z",
  print:     "M5 4V2h6v2M3 11V6h10v5M5 11h6v3H5z",
  share:     "M11 4l-3 3-3-3M8 7V2M3 10v3a1 1 0 001 1h8a1 1 0 001-1v-3",
};

// formatting helpers
const fmtMoney = (v, unit = '万') => {
  if (v == null) return '—';
  const s = Math.abs(v).toLocaleString('zh-CN', { minimumFractionDigits: v % 1 === 0 ? 0 : 2, maximumFractionDigits: 2 });
  return (v < 0 ? '−' : '') + s + (unit ? `\u00a0${unit}` : '');
};
const fmtPct = (v, dp = 1) => v == null ? '—' : `${v.toFixed(dp)}%`;
const fmtInt = (v) => v == null ? '—' : v.toLocaleString('zh-CN');

// Status helper
const statusForPct = (p) => p >= 90 ? 'ok' : p >= 60 ? 'warn' : 'bad';

// SectionHead
function SectionHead({ kicker, title, sub, action }) {
  return (
    <div className="section-head">
      <div>
        {kicker && <div className="kicker-rule">{kicker}</div>}
        <h2>{title}</h2>
      </div>
      {(sub || action) && (
        <div style={{display:'flex', alignItems:'center', gap: 12}}>
          {sub && <span className="sub">{sub}</span>}
          {action}
        </div>
      )}
    </div>
  );
}

// CardHead with optional menu
function CardHead({ title, sub, action }) {
  return (
    <div className="card-head">
      <div>
        <h3>{title}</h3>
        {sub && <div className="sub" style={{marginTop:2}}>{sub}</div>}
      </div>
      {action}
    </div>
  );
}

// Bar in cell
function CellBar({ pct, status }) {
  const cls = status || statusForPct(pct);
  return (
    <div className="cell-bar">
      <span className="cell-bar-pct">{pct.toFixed(1)}%</span>
      <div className="cell-bar-track">
        <div className={`cell-bar-fill ${cls}`} style={{ width: `${Math.min(100, pct)}%` }} />
      </div>
    </div>
  );
}

// Stacked horizontal usage bar (used / pre-occupied / remaining)
function UsageBar({ used, pre, total, height = 8 }) {
  const usedPct = (used / total) * 100;
  const prePct = (pre / total) * 100;
  return (
    <div style={{
      width: '100%', height, borderRadius: height/2,
      background: 'var(--paper-2)', overflow: 'hidden', display: 'flex',
    }}>
      <div style={{ width: `${usedPct}%`, background: 'var(--accent)' }} />
      <div style={{ width: `${prePct}%`, background: 'var(--accent-soft)' }} />
    </div>
  );
}

// Donut (semicircle for KPI gauge)
function Donut({ value, size = 100, stroke = 8, accent = 'var(--accent)' }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - value / 100);
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--line)" strokeWidth={stroke} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={accent} strokeWidth={stroke}
        strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round"
        transform={`rotate(-90 ${size/2} ${size/2})`} />
    </svg>
  );
}

// Tiny sparkline
function Spark({ data, w = 80, h = 24, color = 'var(--accent)' }) {
  if (!data || data.length < 2) return null;
  const max = Math.max(...data), min = Math.min(...data);
  const span = max - min || 1;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / span) * (h - 4) - 2;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ display: 'block' }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// Empty state for upload-required pages
function UploadHero({ title, hint, onUpload, sample }) {
  return (
    <div style={{
      background: 'var(--surface)',
      border: '1px dashed var(--line-2)',
      borderRadius: 'var(--r-lg)',
      padding: '40px 32px',
      display: 'flex',
      alignItems: 'center',
      gap: 24,
    }}>
      <div style={{
        width: 56, height: 56, borderRadius: 12,
        background: 'var(--accent-soft)', color: 'var(--accent)',
        display: 'grid', placeItems: 'center', flexShrink: 0,
      }}>
        <Icn d={I.upload} size={22} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--ink)' }}>{title}</div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-3)', marginTop: 4 }}>{hint}</div>
      </div>
      <button className="btn ghost" onClick={sample}>查看示例数据</button>
      <button className="btn primary" onClick={onUpload}>
        <Icn d={I.upload} /> 上传 .xlsx
      </button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Manager detail drawer — opens when clicking a name in tables.
// Mirrors the original project's 点击管理员 → 工程明细 interaction.
// ─────────────────────────────────────────────────────────────
function ManagerDrawer({ manager, onClose }) {
  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  if (!manager) return null;

  const projects = window.DATA.projects
    .filter(p => p.manager === manager.name)
    .sort((a, b) => b.balance - a.balance);

  const totalBalance = projects.reduce((s, p) => s + p.balance, 0);
  const totalSpend   = projects.reduce((s, p) => s + p.spendYTD, 0);
  const totalPending = projects.reduce((s, p) => s + p.pending, 0);
  const activeCount  = projects.filter(p => p.balance > 0).length;
  const reversedCount = projects.filter(p => p.spendYTD < 0).length;

  return (
    <>
      <div className="drawer-backdrop" onClick={onClose}/>
      <aside className="drawer" role="dialog" aria-label={`${manager.name} 工程明细`}>
        <header className="drawer-head">
          <div style={{minWidth: 0, flex: 1}}>
            <div className="eyebrow">工程管理员 · 明细</div>
            <h2>{manager.name}</h2>
            <div style={{
              display: 'flex', gap: 14, marginTop: 10,
              fontSize: 12, color: 'var(--ink-3)', flexWrap: 'wrap'
            }}>
              <span>排名 <strong style={{color:'var(--ink-2)'}}>#{manager.rank || '—'}</strong></span>
              <span className="sep" style={{width:3,height:3,background:'var(--ink-4)',borderRadius:'50%',alignSelf:'center'}}/>
              <span>在管 <strong style={{color:'var(--ink-2)'}}>{manager.projects}</strong> 项 · 在建 {activeCount}</span>
              <span className="sep" style={{width:3,height:3,background:'var(--ink-4)',borderRadius:'50%',alignSelf:'center'}}/>
              <span>转固率 <strong style={{color:'var(--ink-2)'}}>{manager.rate.toFixed(2)}%</strong></span>
              {reversedCount > 0 && (
                <span className="pill warn" style={{fontSize:10}}>
                  <span className="dot"/>{reversedCount} 项冲回
                </span>
              )}
            </div>
          </div>
          <button className="drawer-close" onClick={onClose} aria-label="关闭">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
              <path d="M3 3l10 10M13 3L3 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </button>
        </header>

        <div className="drawer-body">
          {/* Financial summary */}
          <div className="section">
            <SectionHead title="财务摘要" sub="单位：万元"/>
            <div className="stat-grid">
              <div className="stat">
                <div className="stat-label">在建工程期末余额</div>
                <div className="stat-value">{fmtMoney(manager.balance, '')}<span className="unit">万</span></div>
              </div>
              <div className="stat">
                <div className="stat-label">本年累计资本性支出</div>
                <div className={`stat-value ${manager.spendYTD < 0 ? 'neg' : ''}`}>
                  {fmtMoney(manager.spendYTD, '')}<span className="unit">万</span>
                </div>
              </div>
              <div className="stat">
                <div className="stat-label">本月资本性支出</div>
                <div className={`stat-value ${manager.spendMo < 0 ? 'neg' : ''}`}>
                  {fmtMoney(manager.spendMo, '')}<span className="unit">万</span>
                </div>
              </div>
              <div className="stat">
                <div className="stat-label">结转额 · 期初</div>
                <div className="stat-value">{fmtMoney(manager.carryover, '')}<span className="unit">万</span></div>
              </div>
              <div className="stat">
                <div className="stat-label">已下单待收货</div>
                <div className="stat-value">{fmtMoney(manager.pending, '')}<span className="unit">万</span></div>
              </div>
              <div className="stat">
                <div className="stat-label">转固率</div>
                <div className="stat-value">{manager.rate.toFixed(2)}<span className="unit">%</span></div>
              </div>
            </div>
          </div>

          {/* Projects detail */}
          <div className="section">
            <SectionHead
              title={`所属工程明细 · ${projects.length} 项`}
              sub={<>期末余额合计 <strong style={{color:'var(--ink)'}}>{fmtMoney(totalBalance, '万')}</strong></>}
            />
            {projects.length === 0 ? (
              <div className="empty">暂无工程记录</div>
            ) : (
              <div className="card">
                <table className="tbl">
                  <thead>
                    <tr>
                      <th style={{width:28}}>#</th>
                      <th>工程名称</th>
                      <th className="num">期末余额</th>
                      <th className="num">本年支出</th>
                      <th className="num">本月</th>
                      <th className="num">待到货</th>
                      <th>转固率</th>
                    </tr>
                  </thead>
                  <tbody>
                    {projects.map((p, i) => (
                      <tr key={p.name}>
                        <td className="mono muted">{i+1}</td>
                        <td className="col-name" title={p.name} style={{
                          maxWidth: 280, overflow: 'hidden',
                          textOverflow: 'ellipsis', whiteSpace: 'nowrap'
                        }}>{p.name}</td>
                        <td className="num mono" style={{fontWeight: 500}}>{fmtMoney(p.balance, '')}</td>
                        <td className="num mono" style={{color: p.spendYTD < 0 ? 'var(--bad)' : 'var(--ink-2)'}}>
                          {fmtMoney(p.spendYTD, '')}
                        </td>
                        <td className="num mono" style={{color: p.spendMo < 0 ? 'var(--bad)' : p.spendMo > 0 ? 'var(--ok)' : 'var(--ink-3)'}}>
                          {fmtMoney(p.spendMo, '')}
                        </td>
                        <td className="num mono muted">{fmtMoney(p.pending, '')}</td>
                        <td><CellBar pct={Math.min(p.rate * 100, 100)}/></td>
                      </tr>
                    ))}
                    <tr style={{background: 'var(--surface-2)'}}>
                      <td/>
                      <td className="col-name" style={{color: 'var(--ink-3)', fontWeight: 500}}>合计</td>
                      <td className="num mono" style={{fontWeight: 500}}>{fmtMoney(totalBalance, '')}</td>
                      <td className="num mono" style={{color: totalSpend < 0 ? 'var(--bad)' : 'var(--ink-2)', fontWeight: 500}}>
                        {fmtMoney(totalSpend, '')}
                      </td>
                      <td/>
                      <td className="num mono muted">{fmtMoney(totalPending, '')}</td>
                      <td/>
                    </tr>
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        <footer className="drawer-foot">
          <span>Esc 关闭 · 点击其他名字可跳转</span>
          <div style={{display:'flex', gap:8}}>
            <button className="btn ghost"><Icn d={I.download} size={12}/> 导出此人明细</button>
            <button className="btn"><Icn d={I.print} size={12}/> 打印</button>
          </div>
        </footer>
      </aside>
    </>
  );
}

Object.assign(window, {
  Icn, I, fmtMoney, fmtPct, fmtInt, statusForPct,
  SectionHead, CardHead, CellBar, UsageBar, Donut, Spark, UploadHero,
  ManagerDrawer,
});
