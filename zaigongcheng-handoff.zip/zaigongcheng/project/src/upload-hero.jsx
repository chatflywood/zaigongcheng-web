// upload-hero.jsx — always-on upload strip for 在建 / 预算 pages

function UploadStrip({ module, filename, date, rows, recordId, onReplace, onHistory }) {
  // module: 'zaigong' | 'budget'
  const label = module === 'zaigong' ? '在建工程分析.xlsx' : '预算立项数据.xlsx';
  const fileRef = React.useRef(null);

  return (
    <div className="upload-strip">
      <div className="up-icon"><Icn d={I.doc} size={20}/></div>
      <div className="up-meta">
        <div className="up-title">
          {filename || label}
          {filename && <span className="up-badge">已加载</span>}
        </div>
        <div className="up-sub">
          {date && <span>数据日期 {date}</span>}
          {rows != null && <span> · 共 {rows} 行</span>}
          {recordId && <span> · 记录 #{recordId}</span>}
          {!filename && <span>尚未上传 · 请选择 .xlsx</span>}
        </div>
      </div>
      <div className="up-meter">
        <b>{window.DATA.totalProjects}</b>
        <span>PROJECTS</span>
      </div>
      <div style={{display:'flex', gap:6}}>
        <button className="btn ghost" onClick={onHistory}>
          <Icn d={I.calendar} size={12}/> 历史记录
        </button>
        <input ref={fileRef} type="file" accept=".xlsx,.xls" hidden
          onChange={(e) => { if (e.target.files[0] && onReplace) onReplace(e.target.files[0]); }} />
        <button className="btn primary" onClick={() => fileRef.current?.click()}>
          <Icn d={I.upload} size={12}/> 替换源文件
        </button>
      </div>
    </div>
  );
}

window.UploadStrip = UploadStrip;
