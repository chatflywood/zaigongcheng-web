// app.jsx — root, page routing, tweaks panel, edit-mode wiring

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "variant": "editorial",
  "density": "comfortable",
  "sidebarStyle": "default"
}/*EDITMODE-END*/;

function useStored(key, initial) {
  const [v, setV] = React.useState(() => {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : initial; } catch { return initial; }
  });
  React.useEffect(() => { try { localStorage.setItem(key, JSON.stringify(v)); } catch {} }, [key, v]);
  return [v, setV];
}

function App() {
  const [page, setPage]       = useStored('xt:page', 'overview');
  const [tweaks, setTweaks]   = React.useState(TWEAK_DEFAULTS);
  const [tweaksOpen, setOpen] = React.useState(false);

  // Apply variant + density to <html>
  React.useEffect(() => {
    document.documentElement.setAttribute('data-variant', tweaks.variant);
    document.documentElement.setAttribute('data-density', tweaks.density);
  }, [tweaks]);

  // Edit-mode protocol
  React.useEffect(() => {
    const onMsg = (e) => {
      if (!e.data || typeof e.data !== 'object') return;
      if (e.data.type === '__activate_edit_mode')   setOpen(true);
      if (e.data.type === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  const setTweak = (k, v) => {
    setTweaks(prev => {
      const next = { ...prev, [k]: v };
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: { [k]: v } }, '*');
      return next;
    });
  };

  let Page = PageOverview;
  if (page === 'dashboard') Page = PageDashboard;
  else if (page === 'budget') Page = PageBudget;
  else if (page === 'kpi')    Page = PageKPI;

  return (
    <div className="app">
      <Sidebar page={page} setPage={setPage} />
      <main className="canvas" data-screen-label={`${pageLabel(page)}`}>
        <Page goto={setPage} />
      </main>
      {tweaksOpen && <TweaksPanel tweaks={tweaks} set={setTweak} close={() => setOpen(false)} />}
    </div>
  );
}

function pageLabel(p) {
  return p === 'overview' ? '00 设计说明'
       : p === 'dashboard' ? '01 在建工程'
       : p === 'budget'    ? '02 预算立项'
       : p === 'kpi'       ? '03 关键指标'
       : p;
}

function TweaksPanel({ tweaks, set, close }) {
  const Seg = ({ value, options, onChange }) => (
    <div className="tweak-seg">
      {options.map(o => (
        <button key={o.v} className={value === o.v ? 'on' : ''} onClick={() => onChange(o.v)}>{o.l}</button>
      ))}
    </div>
  );
  return (
    <div className="tweaks">
      <div className="tweaks-head">
        <strong>Tweaks</strong>
        <button onClick={close} title="关闭">×</button>
      </div>
      <div className="tweaks-body">
        <div className="tweak-row">
          <span className="tweak-label">视觉方向 · Variant</span>
          <Seg value={tweaks.variant} onChange={v => set('variant', v)} options={[
            { v: 'editorial', l: 'Editorial' },
            { v: 'software',  l: 'Software' },
            { v: 'print',     l: 'Print' },
          ]}/>
          <span style={{ fontSize: 10.5, color: 'var(--ink-3)', marginTop: 2, lineHeight: 1.5 }}>
            {tweaks.variant === 'editorial' && '纸感背景 · Claude orange · 最克制'}
            {tweaks.variant === 'software'  && 'Linear 风 · 冷灰白 · 紧凑工程感'}
            {tweaks.variant === 'print'     && '近黑白 · 琥珀强调 · 截图友好'}
          </span>
        </div>
        <div className="tweak-row">
          <span className="tweak-label">密度 · Density</span>
          <Seg value={tweaks.density} onChange={v => set('density', v)} options={[
            { v: 'compact',     l: '紧凑' },
            { v: 'comfortable', l: '舒适' },
            { v: 'loose',       l: '宽松' },
          ]}/>
        </div>
        <div style={{ paddingTop: 10, borderTop: '1px dashed var(--line)', fontSize: 10.5, color: 'var(--ink-3)', lineHeight: 1.6 }}>
          切换在所有页面生效。当前选择会保存到本地，刷新后保留。
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
