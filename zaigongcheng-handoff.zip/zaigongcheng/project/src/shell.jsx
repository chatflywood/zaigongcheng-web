// shell.jsx — sidebar + page chrome

function Sidebar({ page, setPage }) {
  const nav = [
    { group: '分析', items: [
      { id: 'overview',  label: '设计说明',     icn: I.sparkle },
      { id: 'dashboard', label: '在建工程',     icn: I.layers,  badge: '24' },
      { id: 'budget',    label: '预算立项',     icn: I.chart },
      { id: 'kpi',       label: '关键指标',     icn: I.gauge },
    ]},
    { group: '工具', items: [
      { id: 'rules',     label: '预警规则',     icn: I.command,   disabled: true },
      { id: 'export',    label: '导出与分享',   icn: I.download,  disabled: true },
      { id: 'history',   label: '上传历史',     icn: I.calendar,  disabled: true },
    ]},
  ];
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">CTC</div>
        <div>
          <div className="brand-name">工程数据分析</div>
          <span className="brand-sub">仙桃 · 云网发展部</span>
        </div>
      </div>

      {nav.map(g => (
        <div className="side-section" key={g.group}>
          <div className="side-label">{g.group}</div>
          {g.items.map(it => (
            <div
              key={it.id}
              className={`side-link ${page === it.id ? 'active' : ''}`}
              onClick={() => !it.disabled && setPage(it.id)}
              style={it.disabled ? { opacity: 0.45, cursor: 'default' } : null}
            >
              <Icn d={it.icn} />
              <span style={{ flex: 1 }}>{it.label}</span>
              {it.badge && (
                <span style={{
                  fontFamily: 'var(--font-mono)', fontSize: 10,
                  color: 'var(--ink-3)', padding: '1px 5px',
                  background: 'var(--paper)', borderRadius: 3,
                }}>{it.badge}</span>
              )}
              {it.disabled && (
                <span style={{ fontSize: 10, color: 'var(--ink-4)' }}>WIP</span>
              )}
            </div>
          ))}
        </div>
      ))}

      <div className="side-foot">
        <strong>当月窗口</strong>
        <span>2026.03 · 第 3 季度</span>
        <span style={{ marginTop: 6, color: 'var(--ink-4)' }}>v0.4 · 内部预览</span>
      </div>
    </aside>
  );
}

function PageHead({ eyebrow, title, sub, meta, actions }) {
  return (
    <header className="page-head">
      <div className="page-head-l">
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h1 className="page-title">{title}</h1>
        {sub && <div style={{ fontSize: 14, color: 'var(--ink-2)', marginTop: 4, maxWidth: 640 }}>{sub}</div>}
        {meta && (
          <div className="page-meta">
            {meta.map((m, i) => (
              <React.Fragment key={i}>
                {i > 0 && <span className="sep" />}
                <span>{m}</span>
              </React.Fragment>
            ))}
          </div>
        )}
      </div>
      {actions && <div className="page-actions">{actions}</div>}
    </header>
  );
}

Object.assign(window, { Sidebar, PageHead });
