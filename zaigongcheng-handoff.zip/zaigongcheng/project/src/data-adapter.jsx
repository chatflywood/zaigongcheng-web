// data-adapter.jsx — normalize window.__DATA__ into the shape each page expects
// Source: _data/extracted.json (parsed from the user's actual sqlite analysis.db)

const D = window.__DATA__;

// Manager rows — split into individuals + 合计 total
const _mgrAll = D.managers || [];
const _mgrTotal = _mgrAll.find(m => m['工程管理员'] === '合计') || {};
const _mgrs = _mgrAll.filter(m => m['工程管理员'] !== '合计');

// Normalize project records. Note: 金额 columns in the projects array are in 元,
// but 在建工程期末余额 is already in 万 — verified against manager subtotals.
const _projects = (D.projects || []).map(p => ({
  name: p['工程名称'],
  manager: p['工程管理员'],
  carryover: +(p['结转额'] / 10000).toFixed(2),           // → 万
  spendYTD:  +(p['本年累计资本性支出'] / 10000).toFixed(2),
  pending:   +(p['已下单待收货'] / 10000).toFixed(2),
  spendMo:   +(p['本月资本性支出'] / 10000).toFixed(2),
  balance:   +(p['在建工程期末余额']).toFixed(4),          // already 万
  rate:      p['转固率'] || 0,
})).filter(p => p.name);

// Sort: balance desc for "largest in-progress"
const projectsByBalance = [..._projects].sort((a, b) => b.balance - a.balance);

// Sort: spendYTD desc for "most active"
const projectsBySpend = [..._projects].sort((a, b) => b.spendYTD - a.spendYTD);

// Managers table
const managers = _mgrs.map(m => ({
  name:      m['工程管理员'],
  carryover: +m['结转额'].toFixed(2),                           // 万
  spendYTD:  +m['本年累计资本性支出'].toFixed(2),
  pending:   +m['已下单待收货'].toFixed(2),
  spendMo:   +m['本月资本性支出'].toFixed(2),
  balance:   +(m['在建工程期末余额'] / 10000).toFixed(2),      // 元 → 万
  rate:      m['转固率'] * 100,                                 // → %
  projects:  _projects.filter(p => p.manager === m['工程管理员']).length,
}));

// Rank managers by spendYTD
const managersRanked = [...managers].sort((a, b) => b.spendYTD - a.spendYTD)
  .map((m, i) => ({ ...m, rank: i + 1 }));

// Top-level KPIs (already in 万)
const kpi = {
  spendYTD:       D.kpi.total_current,     // 本年累计资本性支出
  pending:        D.kpi.total_pending,      // 已下单待收货
  spendMo:        D.kpi.total_today_month,  // 本月资本性支出 (can be negative)
  carryover:      D.kpi.total_transfer,     // 结转额 (open balance)
  transferRate:   D.kpi.total_rate * 100,   // 转固率 %
  progressPct:    D.kpi.progress_pct,       // 全年进度 %
  deficit:        D.kpi.deficit,            // 缺口 万
  yearTarget:     D.kpi.year_target,        // 年度目标 万
};

// Budget categories — already in 万
// Filter out empty categories for display; keep full list for reference
const budgetAll = D.budget || [];
const budgetActive = budgetAll.filter(b => b.budget > 0 || b.annual_spend > 0);

const budgetTotals = budgetAll.reduce((acc, b) => ({
  budget:       acc.budget + b.budget,
  annual_spend: acc.annual_spend + b.annual_spend,
  occupied:     acc.occupied + b.occupied,
  preoccupied:  acc.preoccupied + b.preoccupied,
}), { budget: 0, annual_spend: 0, occupied: 0, preoccupied: 0 });

// Catalog — new立项/predictive projects with 占用 marks
const catalog = D.catalog || [];

// Derive warnings from the real data
// - 长期挂账: carryover > 0 AND spendYTD == 0 AND pending == 0 (project stuck)
// - 超期未转固: balance > 0 AND rate > 0.9 (nearly done, not transferred)
// - 预算超支: spend_progress > 1 (actual over budget in that category)
// - 进度滞后: spendYTD < 0 (negative — suggesting reversal/correction)
const warnings = {
  stale:        _projects.filter(p => p.carryover > 0 && p.spendYTD === 0 && p.pending === 0 && p.balance > 0),
  nearlyDone:   _projects.filter(p => p.balance > 0 && p.rate >= 0.9 && p.rate < 1),
  overBudget:   budgetAll.filter(b => b.spend_progress > 1),
  reversed:     _projects.filter(p => p.spendYTD < 0),
};

const warningSummary = [
  { type: '长期挂账',  count: warnings.stale.length,      severity: 'warn', desc: '有结转但年内无支出和到货', rule: 'carryover>0 & spend=0' },
  { type: '接近转固',  count: warnings.nearlyDone.length, severity: 'info', desc: '转固率 ≥ 90% 但未完全转固', rule: 'rate 0.9–0.99' },
  { type: '预算超支',  count: warnings.overBudget.length, severity: 'bad',  desc: '实际执行 > 立项预算',      rule: 'spend/budget > 100%' },
  { type: '冲回/调账', count: warnings.reversed.length,   severity: 'warn', desc: '本年累计支出为负数',       rule: 'spendYTD < 0' },
];

window.DATA = {
  kpi, managers, managersRanked, mgrTotal: _mgrTotal,
  projects: _projects, projectsByBalance, projectsBySpend,
  budget: budgetAll, budgetActive, budgetTotals,
  catalog,
  warnings, warningSummary,
  // convenience
  totalProjects: _projects.length,
  activeProjects: _projects.filter(p => p.balance > 0).length,
};
