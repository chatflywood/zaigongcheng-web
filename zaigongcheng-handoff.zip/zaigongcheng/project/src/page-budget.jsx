// page-budget.jsx — 预算立项 redesign (real data)

function PageBudget() {
  const { budget, budgetActive, budgetTotals, catalog } = window.DATA;
  const [histOpen, setHistOpen] = React.useState(false);

  const usedPct = budgetTotals.budget > 0 ? (budgetTotals.occupied / budgetTotals.budget) * 100 : 0;
  const prePct  = budgetTotals.budget > 0 ? (budgetTotals.preoccupied / budgetTotals.budget) * 100 : 0;
  const remPct  = Math.max(0, 100 - usedPct - prePct);
  const spendVsBudget = budgetTotals.budget > 0 ? (budgetTotals.annual_spend / budgetTotals.budget) * 100 : 0;

  // Swatch color by index — harmonized OKLCH scale
  const swatch = (i) => `oklch(${72 - i*2.5}% 0.10 ${40 + i*22})`;

  return (
    <div className="page">
      <PageHead
        eyebrow="预算立项 / Budget Allocation"
        title="2026 年度预算执行"
        meta={[
          <span><Icn d={I.doc} size={11} style={{verticalAlign:'middle',marginRight:4}}/>预算立项分析.xlsx</span>,
          `${budget.length} 个专业 · ${catalog.length} 个立项`,
          `预算合计 ${budgetTotals.budget.toFixed(2)} 万`,
        ]}
        actions={<>
          <button className="btn ghost" onClick={() => setHistOpen(true)}><Icn d={I.calendar}/> 历史记录</button>
          <button className="btn ghost"><Icn d={I.refresh}/> 刷新</button>
          <button className="btn"><Icn d={I.download}/> 导出</button>
        </>}
      />

      <UploadStrip
        module="budget"
        filename="预算立项_20260318.xlsx"
        date="2026-03-18"
        rows={budget.length}
        recordId={980}
        onHistory={() => setHistOpen(true)}
      />

      {/* — Hero — */}
      <div className="section" style={{ marginBottom: 48 }}>
        <div className="card" style={{ padding: '32px 36px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 32, marginBottom: 28 }}>
            <div>
              <div style={{ fontSize: 11.5, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>年度预算</div>
              <div style={{ fontSize: 36, fontWeight: 500, color: 'var(--ink)', letterSpacing: '-0.025em', lineHeight: 1, fontFamily: 'var(--font-mono)' }}>
                {budgetTotals.budget.toFixed(2)}
                <span style={{ fontSize: 14, color: 'var(--ink-3)', marginLeft: 6, fontFamily: 'var(--font-sans)', fontWeight: 400 }}>万</span>
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 8 }}>预算入账总额</div>
            </div>
            <div>
              <div style={{ fontSize: 11.5, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>已占用</div>
              <div style={{ fontSize: 36, fontWeight: 500, color: 'var(--accent)', letterSpacing: '-0.025em', lineHeight: 1, fontFamily: 'var(--font-mono)' }}>
                {budgetTotals.occupied.toFixed(2)}
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 8 }}>占预算 <span className="mono" style={{ color: 'var(--ink)' }}>{usedPct.toFixed(1)}%</span></div>
            </div>
            <div>
              <div style={{ fontSize: 11.5, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>全年支出</div>
              <div style={{ fontSize: 36, fontWeight: 500, color: 'var(--ink-2)', letterSpacing: '-0.025em', lineHeight: 1, fontFamily: 'var(--font-mono)' }}>
                {budgetTotals.annual_spend.toFixed(2)}
              </div>
              <div style={{ fontSize: 12, color: spendVsBudget > 100 ? 'var(--bad)' : 'var(--ink-3)', marginTop: 8 }}>
                占预算 <span className="mono">{spendVsBudget.toFixed(1)}%</span> {spendVsBudget > 100 && '⚠'}
              </div>
            </div>
            <div>
              <div style={{ fontSize: 11.5, color: 'var(--ink-3)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>剩余可调度</div>
              <div style={{ fontSize: 36, fontWeight: 500, color: 'var(--ink)', letterSpacing: '-0.025em', lineHeight: 1, fontFamily: 'var(--font-mono)' }}>
                {(budgetTotals.budget - budgetTotals.occupied - budgetTotals.preoccupied).toFixed(2)}
              </div>
              <div style={{ fontSize: 12, color: 'var(--ink-3)', marginTop: 8 }}>{remPct.toFixed(1)}% 未分配</div>
            </div>
          </div>

          <div>
            <div style={{ display: 'flex', height: 12, borderRadius: 6, overflow: 'hidden', background: 'var(--paper-2)' }}>
              <div style={{ width: `${usedPct}%`, background: 'var(--accent)' }}/>
              <div style={{ width: `${prePct}%`, background: 'var(--accent-soft)' }}/>
            </div>
            <div style={{ display: 'flex', gap: 24, marginTop: 12, fontSize: 12, color: 'var(--ink-2)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 8, height: 8, background: 'var(--accent)', borderRadius: 2 }}/>已占用 <span className="mono" style={{ color: 'var(--ink)' }}>{usedPct.toFixed(1)}%</span></div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 8, height: 8, background: 'var(--accent-soft)', borderRadius: 2 }}/>预占用 <span className="mono" style={{ color: 'var(--ink)' }}>{prePct.toFixed(1)}%</span></div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><span style={{ width: 8, height: 8, background: 'var(--paper-2)', borderRadius: 2, border: '1px solid var(--line)' }}/>剩余 <span className="mono" style={{ color: 'var(--ink)' }}>{remPct.toFixed(1)}%</span></div>
            </div>
          </div>
        </div>
      </div>

      {/* — By major — */}
      <div className="section">
        <SectionHead title="按专业拆分" sub={<>共 <strong>{budget.length}</strong> 个专业 · 其中 <strong>{budgetActive.length}</strong> 有预算或支出</>}/>
        <div className="card">
          <table className="tbl">
            <thead>
              <tr>
                <th style={{width:24}}></th>
                <th>专业</th>
                <th className="num">预算</th>
                <th className="num">已占用</th>
                <th className="num">全年支出</th>
                <th>占用结构</th>
                <th className="num">执行率</th>
              </tr>
            </thead>
            <tbody>
              {budget.map((row, i) => {
                const up = row.budget > 0 ? (row.occupied / row.budget) * 100 : 0;
                const pp = row.budget > 0 ? (row.preoccupied / row.budget) * 100 : 0;
                const sp = row.spend_progress * 100;
                return (
                  <tr key={row.name} style={{ opacity: row.budget === 0 && row.annual_spend === 0 ? 0.45 : 1 }}>
                    <td><span style={{ display: 'block', width: 8, height: 8, borderRadius: 2, background: swatch(i) }}/></td>
                    <td className="col-name">{row.name}</td>
                    <td className="num mono">{row.budget > 0 ? row.budget.toFixed(2) : '—'}</td>
                    <td className="num mono" style={{ color: 'var(--ink)', fontWeight: row.occupied > 0 ? 500 : 400 }}>{row.occupied > 0 ? row.occupied.toFixed(2) : '—'}</td>
                    <td className="num mono" style={{ color: sp > 100 ? 'var(--bad)' : 'var(--ink-2)' }}>{row.annual_spend > 0 ? row.annual_spend.toFixed(2) : '—'}</td>
                    <td style={{ minWidth: 240 }}>
                      {row.budget > 0 ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                          <div style={{ flex: 1, display: 'flex', height: 6, borderRadius: 3, overflow: 'hidden', background: 'var(--paper-2)' }}>
                            <div style={{ width: `${Math.min(up, 100)}%`, background: up > 100 ? 'var(--bad)' : 'var(--accent)' }}/>
                            <div style={{ width: `${pp}%`, background: 'var(--accent-soft)' }}/>
                          </div>
                          <span className="mono" style={{ fontSize: 11.5, color: 'var(--ink-2)', width: 56, textAlign: 'right' }}>{(up+pp).toFixed(1)}%</span>
                        </div>
                      ) : <span className="muted" style={{ fontSize: 11 }}>无预算</span>}
                    </td>
                    <td className="num mono" style={{ color: sp > 100 ? 'var(--bad)' : sp > 80 ? 'var(--warn)' : 'var(--ink-2)' }}>
                      {row.budget > 0 ? `${sp.toFixed(1)}%` : '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* — Catalog / 立项清单 — */}
      {catalog.length > 0 && (
        <div className="section">
          <SectionHead title="2026 年立项清单" sub={<>共 <strong>{catalog.length}</strong> 个立项项目 · 来源：立项表</>} action={
            <button className="btn"><Icn d={I.search}/> 筛选</button>
          }/>
          <div className="card">
            <table className="tbl">
              <thead>
                <tr>
                  <th>立项编号</th>
                  <th>项目名称</th>
                  <th>专业</th>
                  <th>负责人</th>
                  <th className="num">占用预算</th>
                  <th className="num">预占用</th>
                </tr>
              </thead>
              <tbody>
                {catalog.map(p => (
                  <tr key={p.code}>
                    <td className="mono" style={{ color: 'var(--ink-3)', fontSize: 12 }}>{p.code}</td>
                    <td className="col-name" title={p.name}>{p.name}</td>
                    <td className="muted">{p.category}</td>
                    <td>{p.manager}</td>
                    <td className="num mono" style={{ fontWeight: p.occupied > 0 ? 500 : 400, color: p.occupied > 0 ? 'var(--ink)' : 'var(--ink-4)' }}>
                      {p.occupied > 0 ? p.occupied.toFixed(2) : '—'}
                    </td>
                    <td className="num mono muted">{p.preoccupied > 0 ? p.preoccupied.toFixed(2) : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {histOpen && <HistoryCenter onClose={() => setHistOpen(false)} />}
    </div>
  );
}

window.PageBudget = PageBudget;
