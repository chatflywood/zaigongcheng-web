// history-center.jsx — full-screen overlay with tabs, cards, A/B compare, trend chart.
// Mirrors the Vue original's 历史记录中心 (App.vue) — data is synthesized from the
// single real snapshot in window.DATA by perturbing it along a plausible timeline.

function buildMockHistory() {
  const D = window.DATA;
  const now = new Date();
  const iso = (d) => d.toISOString().slice(0,16).replace('T',' ');
  const fdate = (d) => `${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`;

  // 8 zaigong snapshots, latest first — the "real" record is #1.
  const zaigong = Array.from({length: 8}, (_, i) => {
    const d = new Date(now); d.setDate(now.getDate() - i*7);
    // Walk metrics back over time (earlier = lower spend, lower rate).
    const scale = 1 - i * 0.07;                // 1.0 → 0.51
    const progress = Math.max(D.kpi.progressPct * scale, 3);
    const rate     = Math.max(D.kpi.transferRate * scale * 0.01, 0.004); // kept as fraction (0..1)
    const capital  = Math.max(D.kpi.spendYTD * scale, 0);
    return {
      id: 1200 - i * 3,
      source_filename: `在建工程分析_2026${fdate(d)}.xlsx`,
      uploaded_at: iso(d) + ':00',
      file_date: `2026${fdate(d)}`,
      target_value: D.kpi.yearTarget,
      metrics: {
        progress_pct: progress,
        total_rate: rate,
        total_current: capital,
      },
    };
  });

  const budget = Array.from({length: 6}, (_, i) => {
    const d = new Date(now); d.setDate(now.getDate() - i*10);
    const scale = 1 - i * 0.08;
    return {
      id: 980 - i * 2,
      source_filename: `预算立项_${d.getFullYear()}${fdate(d)}.xlsx`,
      uploaded_at: iso(d) + ':00',
      file_date: null,
      budget_total: D.budgetTotals.budget,
      approval_progress: Math.max(0.78 * scale, 0.1),
      annual_spend: Math.max(D.budgetTotals.annual_spend * scale, 0),
    };
  });

  return { zaigong, budget };
}

function TrendChart({ records }) {
  if (!records || records.length < 2) {
    return <div className="empty">数据不足，需至少 2 次历史记录。</div>;
  }
  const rs = [...records].reverse(); // oldest → newest (left → right)
  const L = 48, T = 16, W = 560, H = 200, YMAX = 130;
  const n = rs.length;
  const step = (W - L - 20) / (n - 1);
  const px = (i) => L + i * step;
  const py = (v) => T + H - Math.min(Math.max(v, 0), YMAX) / YMAX * H;

  const progPts = rs.map((r, i) => {
    const v = r.metrics.progress_pct || 0;
    return { x: px(i), y: py(v), v: v.toFixed(1) };
  });
  const ratePts = rs.map((r, i) => {
    const v = (r.metrics.total_rate || 0) * 100;
    return { x: px(i), y: py(v), v: v.toFixed(1) };
  });
  const labels = rs.map((r, i) => {
    const fd = r.file_date || '';
    return { x: px(i), text: fd ? `${fd.slice(4,6)}-${fd.slice(6)}` : String(i+1) };
  });
  const yTicks = [0, 30, 60, 90, 120].map(v => ({ y: py(v), label: `${v}%` }));

  return (
    <div className="trend-wrap">
      <div className="trend-legend">
        <span><span className="dot" style={{background:'var(--info)'}}/>支出进度</span>
        <span><span className="dot" style={{background:'var(--warn)'}}/>转固率</span>
        <span style={{marginLeft:'auto', color: 'var(--ink-4)'}}>— 60% 转固目标</span>
      </div>
      <svg viewBox={`0 0 ${W + 20} 260`} style={{width: '100%', display: 'block'}}>
        {yTicks.map(t => (
          <g key={t.label}>
            <line x1={L} y1={t.y} x2={W} y2={t.y} stroke="var(--line)" strokeWidth="1"/>
            <text x={L - 6} y={t.y + 3} textAnchor="end" fontSize="10" fill="var(--ink-4)">{t.label}</text>
          </g>
        ))}
        <line x1={L} y1={py(60)} x2={W} y2={py(60)} stroke="var(--warn)" strokeOpacity="0.4" strokeWidth="1" strokeDasharray="5 4"/>
        <polyline points={progPts.map(p=>`${p.x},${p.y}`).join(' ')} fill="none" stroke="var(--info)" strokeWidth="2" strokeLinejoin="round"/>
        <polyline points={ratePts.map(p=>`${p.x},${p.y}`).join(' ')} fill="none" stroke="var(--warn)" strokeWidth="2" strokeLinejoin="round"/>
        {progPts.map((p,i) => (
          <g key={'p'+i}>
            <circle cx={p.x} cy={p.y} r="3.5" fill="var(--info)"/>
            {n <= 10 && <text x={p.x} y={p.y - 8} textAnchor="middle" fontSize="9" fill="var(--info)">{p.v}%</text>}
          </g>
        ))}
        {ratePts.map((p,i) => (
          <g key={'r'+i}>
            <circle cx={p.x} cy={p.y} r="3.5" fill="var(--warn)"/>
            {n <= 10 && <text x={p.x} y={p.y - 8} textAnchor="middle" fontSize="9" fill="var(--warn)">{p.v}%</text>}
          </g>
        ))}
        {labels.map(lb => (
          <text key={'l'+lb.x} x={lb.x} y={H + T + 20} textAnchor="middle" fontSize="10" fill="var(--ink-3)" fontFamily="var(--font-mono)">{lb.text}</text>
        ))}
      </svg>
    </div>
  );
}

function HistoryCard({ rec, kind, aSel, bSel, onSelect, onOpen }) {
  const isA = aSel?.id === rec.id;
  const isB = bSel?.id === rec.id;
  return (
    <div className={`hist-card ${isA || isB ? 'active' : ''}`} onClick={() => onOpen(rec)}>
      <div className="hc-top">
        <span className="hc-name" title={rec.source_filename}>{rec.source_filename}</span>
        <span className="hc-id">#{rec.id}</span>
      </div>
      <div className="hc-chips">
        <span className="hc-chip">{rec.uploaded_at}</span>
        {rec.file_date && <span className="hc-chip">数据 {rec.file_date.slice(4,6)}-{rec.file_date.slice(6)}</span>}
        {rec.target_value && <span className="hc-chip target">目标 {rec.target_value} 万</span>}
      </div>
      {kind === 'zaigong' && rec.metrics && (
        <div className="hc-kpi">
          <div className="k"><em>支出进度</em><b>{(rec.metrics.progress_pct || 0).toFixed(1)}%</b></div>
          <div className="k"><em>转固率</em><b>{((rec.metrics.total_rate || 0) * 100).toFixed(1)}%</b></div>
          <div className="k"><em>资本支出</em><b>{(rec.metrics.total_current || 0).toFixed(0)}<span style={{fontSize:9,color:'var(--ink-3)',marginLeft:2}}>万</span></b></div>
        </div>
      )}
      {kind === 'budget' && (
        <div className="hc-kpi">
          <div className="k"><em>年度预算</em><b>{(rec.budget_total || 0).toFixed(0)}<span style={{fontSize:9,color:'var(--ink-3)',marginLeft:2}}>万</span></b></div>
          <div className="k"><em>立项进度</em><b>{((rec.approval_progress || 0)*100).toFixed(1)}%</b></div>
          <div className="k"><em>累计支出</em><b>{(rec.annual_spend || 0).toFixed(0)}<span style={{fontSize:9,color:'var(--ink-3)',marginLeft:2}}>万</span></b></div>
        </div>
      )}
      <div className="hc-ab" onClick={(e)=>e.stopPropagation()}>
        <button className={isA ? 'on' : ''} onClick={()=>onSelect('left', rec)} title="设为对比 A">A</button>
        <button className={isB ? 'on' : ''} onClick={()=>onSelect('right', rec)} title="设为对比 B">B</button>
      </div>
    </div>
  );
}

function ComparePanel({ kind, aSel, bSel }) {
  if (!aSel || !bSel || aSel.id === bSel.id) {
    return (
      <div className="hist-compare">
        <h4>历史对比</h4>
        <div style={{fontSize: 11.5, color: 'var(--ink-3)'}}>在任意两条记录上点击 A / B 即可对比。</div>
      </div>
    );
  }
  if (kind === 'zaigong') {
    const capA = aSel.metrics.total_current, capB = bSel.metrics.total_current;
    const progA = aSel.metrics.progress_pct, progB = bSel.metrics.progress_pct;
    const rateA = aSel.metrics.total_rate * 100, rateB = bSel.metrics.total_rate * 100;
    return (
      <div className="hist-compare">
        <h4>历史对比 · {aSel.file_date || aSel.uploaded_at} → {bSel.file_date || bSel.uploaded_at}</h4>
        <div className="cmp-grid">
          <div className="cmp-card">
            <div className="l">资本性支出</div>
            <div className="v">{capB.toFixed(1)} 万</div>
            <div className={`d ${capB >= capA ? 'up' : 'down'}`}>
              {capB >= capA ? '▲' : '▼'} {Math.abs(capB - capA).toFixed(1)} 万 · 进度 {(progB - progA >= 0 ? '+' : '') + (progB - progA).toFixed(1)}pp
            </div>
          </div>
          <div className="cmp-card">
            <div className="l">转固率</div>
            <div className="v">{rateB.toFixed(2)}%</div>
            <div className={`d ${rateB >= rateA ? 'up' : 'down'}`}>
              {rateB >= rateA ? '▲' : '▼'} {Math.abs(rateB - rateA).toFixed(2)}pp
            </div>
          </div>
        </div>
      </div>
    );
  }
  // budget
  const bA = aSel.budget_total, bB = bSel.budget_total;
  const pA = aSel.approval_progress * 100, pB = bSel.approval_progress * 100;
  return (
    <div className="hist-compare">
      <h4>历史对比 · {aSel.uploaded_at} → {bSel.uploaded_at}</h4>
      <div className="cmp-grid">
        <div className="cmp-card">
          <div className="l">年度预算</div>
          <div className="v">{bB.toFixed(1)} 万</div>
          <div className={`d ${bB >= bA ? 'up' : 'down'}`}>
            {bB >= bA ? '▲' : '▼'} {Math.abs(bB - bA).toFixed(1)} 万
          </div>
        </div>
        <div className="cmp-card">
          <div className="l">立项进度</div>
          <div className="v">{pB.toFixed(1)}%</div>
          <div className={`d ${pB >= pA ? 'up' : 'down'}`}>
            {pB >= pA ? '▲' : '▼'} {Math.abs(pB - pA).toFixed(1)}pp
          </div>
        </div>
      </div>
    </div>
  );
}

function HistoryCenter({ onClose }) {
  const [tab, setTab] = React.useState('all');
  const [zA, setZA] = React.useState(null);
  const [zB, setZB] = React.useState(null);
  const [bA, setBA] = React.useState(null);
  const [bB, setBB] = React.useState(null);

  React.useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = prev; };
  }, [onClose]);

  const { zaigong, budget } = React.useMemo(buildMockHistory, []);
  const total = zaigong.length + budget.length;

  const selectZ = (slot, rec) => { slot === 'left' ? setZA(rec) : setZB(rec); };
  const selectB = (slot, rec) => { slot === 'left' ? setBA(rec) : setBB(rec); };

  const tabs = [
    { v: 'all',     l: '全部',     n: total },
    { v: 'zaigong', l: '在建工程', n: zaigong.length },
    { v: 'budget',  l: '预算立项', n: budget.length },
    { v: 'trend',   l: '趋势图',   icn: I.chart },
  ];

  return (
    <div className="hist-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="hist-panel">
        <div className="hist-head">
          <h2>
            <Icn d={I.calendar} size={18}/>
            历史记录中心
            <span className="count">{total} 条</span>
          </h2>
          <button className="drawer-close" onClick={onClose} aria-label="关闭">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
              <path d="M3 3l10 10M13 3L3 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        <div className="hist-tabs">
          {tabs.map(t => (
            <button key={t.v} className={tab === t.v ? 'on' : ''} onClick={() => setTab(t.v)}>
              {t.icn && <Icn d={t.icn} size={11}/>}
              {t.l}
              {t.n != null && <span style={{fontFamily:'var(--font-mono)', fontSize:10, color:'var(--ink-4)', marginLeft:2}}>{t.n}</span>}
            </button>
          ))}
        </div>

        <div className="hist-body">
          {tab === 'trend' ? (
            <div>
              <div className="hist-group-head">
                <h3>在建工程指标趋势 <span className="n">{zaigong.length} 次快照</span></h3>
              </div>
              <TrendChart records={zaigong}/>
            </div>
          ) : (
            <>
              {(tab === 'all' || tab === 'zaigong') && (
                <div>
                  <div className="hist-group-head">
                    <h3>在建工程 <span className="n">{zaigong.length}</span></h3>
                  </div>
                  <div className="hist-cards">
                    {zaigong.map(r => (
                      <HistoryCard key={r.id} rec={r} kind="zaigong"
                        aSel={zA} bSel={zB} onSelect={selectZ} onOpen={() => {}}/>
                    ))}
                  </div>
                  <ComparePanel kind="zaigong" aSel={zA} bSel={zB}/>
                </div>
              )}
              {(tab === 'all' || tab === 'budget') && (
                <div>
                  <div className="hist-group-head">
                    <h3>预算立项 <span className="n">{budget.length}</span></h3>
                  </div>
                  <div className="hist-cards">
                    {budget.map(r => (
                      <HistoryCard key={r.id} rec={r} kind="budget"
                        aSel={bA} bSel={bB} onSelect={selectB} onOpen={() => {}}/>
                    ))}
                  </div>
                  <ComparePanel kind="budget" aSel={bA} bSel={bB}/>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

window.HistoryCenter = HistoryCenter;
