// page-dashboard.jsx — 在建工程 redesign (real data)

function PageDashboard() {
  const { kpi, managers, managersRanked, projectsByBalance, projectsBySpend, warningSummary, totalProjects, activeProjects } = window.DATA;
  const [drawerMgr, setDrawerMgr] = React.useState(null);
  const [histOpen, setHistOpen]   = React.useState(false);
  const openMgr = (name) => {
    const m = managersRanked.find(x => x.name === name) || managers.find(x => x.name === name);
    if (m) setDrawerMgr(m);
  };

  // Top projects by 期末余额 — the "largest in-progress" list
  const topByBalance = projectsByBalance.slice(0, 8);
  // Top projects by spend this year — the "most active"
  const topBySpend = projectsBySpend.filter(p => p.spendYTD > 0).slice(0, 6);

  const kpiCards = [
    { label: '本年累计·资本性支出', value: fmtMoney(kpi.spendYTD, '万'),  sub: '年度目标', subv: `${kpi.yearTarget} 万`, delta: `进度 ${kpi.progressPct}%`, deltaDir: 'up' },
    { label: '结转额 · 期初',          value: fmtMoney(kpi.carryover, '万'), sub: '转固率',   subv: `${kpi.transferRate.toFixed(2)}%`, delta: null },
    { label: '已下单待收货',            value: fmtMoney(kpi.pending, '万'),   sub: '待到货',   subv: `${activeProjects} 项占用`, delta: null },
    { label: '年度缺口',                value: fmtMoney(kpi.deficit, '万'),   sub: '距目标',   subv: `${(100-kpi.progressPct).toFixed(2)}%`, delta: kpi.spendMo >= 0 ? null : `本月 ${kpi.spendMo.toFixed(1)}`, deltaDir: 'down' },
  ];

  return (
    <div className="page">
      <PageHead
        eyebrow="在建工程 / Capex Tracking"
        title="在建工程进度看板"
        meta={[
          <span><Icn d={I.doc} size={11} style={{verticalAlign:'middle',marginRight:4}}/>在建工程分析.xlsx</span>,
          `共 ${totalProjects} 行 · ${activeProjects} 项在建`,
          `年度目标 ${kpi.yearTarget} 万`,
        ]}
        actions={<>
          <button className="btn ghost" onClick={() => setHistOpen(true)}><Icn d={I.calendar}/> 历史记录</button>
          <button className="btn ghost"><Icn d={I.refresh}/> 重新解析</button>
          <button className="btn"><Icn d={I.print}/> 打印</button>
        </>}
      />

      {/* Upload hero — always-on, even with data loaded */}
      <UploadStrip
        module="zaigong"
        filename="在建工程分析_20260318.xlsx"
        date="2026-03-18"
        rows={totalProjects}
        recordId={1200}
        onHistory={() => setHistOpen(true)}
      />

      {/* — KPI row — */}
      <div className="section" style={{ marginBottom: 48 }}>
        <div className="kpi-grid">
          {kpiCards.map((k,i) => (
            <div className="kpi" key={i}>
              <div className="kpi-label">{k.label}</div>
              <div className="kpi-value"><span className="mono">{k.value}</span></div>
              <div className="kpi-foot">
                <span>{k.sub} <strong style={{color:'var(--ink-2)'}}>{k.subv}</strong></span>
                {k.delta && (
                  <span className={`delta ${k.deltaDir}`}>
                    <span className={k.deltaDir === 'up' ? 'tri-up' : 'tri-dn'}/>{k.delta}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* — Warnings + manager ranking — */}
      <div className="section">
        <SectionHead title="预警 & 管理员负荷" sub={<>按真实数据规则推导 · 规则可在下方查看</>}/>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: 24 }}>
          {/* Warnings */}
          <div className="card">
            <CardHead title="四类工程预警" sub="从数据中自动识别" action={<button className="btn ghost"><Icn d={I.filter}/> 规则</button>}/>
            <div className="card-body" style={{ padding: 0 }}>
              {warningSummary.map((w, i) => (
                <div key={i} style={{
                  padding: '16px 20px',
                  borderBottom: i < warningSummary.length - 1 ? '1px solid var(--line)' : 'none',
                  display: 'grid', gridTemplateColumns: '1fr auto auto', alignItems: 'center', gap: 14,
                }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                      <span className={`pill ${w.severity}`}><span className="dot"/>{w.type}</span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--ink-3)' }}>{w.desc}</div>
                  </div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 24, color: 'var(--ink)', fontWeight: 500, letterSpacing: '-0.02em' }}>{w.count}</div>
                  <div style={{ fontSize: 10.5, color: 'var(--ink-4)', fontFamily: 'var(--font-mono)', minWidth: 120, textAlign: 'right' }}>{w.rule}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Manager ranking */}
          <div className="card">
            <CardHead title="管理员工作量排名" sub={`${managersRanked.length} 人 · 按本年累计支出`}/>
            <div className="card-body" style={{ padding: 0 }}>
              <table className="tbl">
                <thead>
                  <tr>
                    <th className="col-rank">#</th>
                    <th>姓名</th>
                    <th className="num">在管</th>
                    <th className="num">本年支出</th>
                    <th className="num">结转</th>
                    <th className="num">待到货</th>
                    <th>转固率</th>
                  </tr>
                </thead>
                <tbody>
                  {managersRanked.map(m => (
                    <tr key={m.name} onClick={() => setDrawerMgr(m)} style={{cursor:'pointer'}}>
                      <td><span className={`rank ${m.rank <= 2 ? 'top' : ''}`}>{m.rank}</span></td>
                      <td className="col-name link">{m.name}</td>
                      <td className="num mono">{m.projects}</td>
                      <td className="num mono" style={{ color: m.spendYTD < 0 ? 'var(--bad)' : 'var(--ink)', fontWeight: 500 }}>{fmtMoney(m.spendYTD, '')}</td>
                      <td className="num mono muted">{fmtMoney(m.carryover, '')}</td>
                      <td className="num mono muted">{fmtMoney(m.pending, '')}</td>
                      <td><CellBar pct={Math.min(m.rate, 100)} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* — Top 8 projects by balance — */}
      <div className="section">
        <SectionHead title="期末余额 · Top 8 项目" sub={<>按在建工程期末余额降序 · 单位：万元</>} action={<>
          <button className="btn ghost"><Icn d={I.search}/> 搜索</button>
          <button className="btn"><Icn d={I.download}/> 导出</button>
        </>}/>
        <div className="card">
          <table className="tbl">
            <thead>
              <tr>
                <th style={{width:28}}>#</th>
                <th>工程名称</th>
                <th>管理员</th>
                <th className="num">期末余额</th>
                <th className="num">本年支出</th>
                <th className="num">待到货</th>
                <th>转固率</th>
              </tr>
            </thead>
            <tbody>
              {topByBalance.map((p, i) => (
                <tr key={p.name}>
                  <td className="mono muted">{i+1}</td>
                  <td className="col-name" title={p.name}>{p.name}</td>
                  <td className="muted link" style={{cursor:'pointer', textDecoration:'underline', textDecorationColor:'var(--line-2)', textUnderlineOffset:3}} onClick={()=>openMgr(p.manager)}>{p.manager}</td>
                  <td className="num mono" style={{ fontWeight: 500 }}>{fmtMoney(p.balance, '')}</td>
                  <td className="num mono" style={{ color: p.spendYTD < 0 ? 'var(--bad)' : 'var(--ink-2)' }}>{fmtMoney(p.spendYTD, '')}</td>
                  <td className="num mono muted">{fmtMoney(p.pending, '')}</td>
                  <td><CellBar pct={Math.min(p.rate * 100, 100)}/></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* — Most active this year — */}
      <div className="section">
        <SectionHead title="本年支出 · Top 6 最活跃" sub="资本性支出金额最高的 6 个项目"/>
        <div className="card">
          <table className="tbl">
            <thead>
              <tr>
                <th style={{width:28}}>#</th>
                <th>工程名称</th>
                <th>管理员</th>
                <th className="num">本年支出</th>
                <th className="num">本月支出</th>
                <th className="num">期末余额</th>
              </tr>
            </thead>
            <tbody>
              {topBySpend.map((p, i) => (
                <tr key={p.name}>
                  <td className="mono muted">{i+1}</td>
                  <td className="col-name" title={p.name}>{p.name}</td>
                  <td className="muted link" style={{cursor:'pointer', textDecoration:'underline', textDecorationColor:'var(--line-2)', textUnderlineOffset:3}} onClick={()=>openMgr(p.manager)}>{p.manager}</td>
                  <td className="num mono" style={{ fontWeight: 500 }}>{fmtMoney(p.spendYTD, '')}</td>
                  <td className="num mono" style={{ color: p.spendMo < 0 ? 'var(--bad)' : p.spendMo > 0 ? 'var(--ok)' : 'var(--ink-3)' }}>{fmtMoney(p.spendMo, '')}</td>
                  <td className="num mono muted">{fmtMoney(p.balance, '')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {drawerMgr && <ManagerDrawer manager={drawerMgr} onClose={() => setDrawerMgr(null)} />}
      {histOpen && <HistoryCenter onClose={() => setHistOpen(false)} />}
    </div>
  );
}

window.PageDashboard = PageDashboard;
